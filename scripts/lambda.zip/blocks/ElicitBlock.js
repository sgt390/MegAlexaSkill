"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ElicitBlock = /** @class */ (function () {
    function ElicitBlock() {
    }
    ElicitBlock.prototype.text = function () {
        throw new Error("Method not implemented.");
    };
    ElicitBlock.prototype.toString = function () {
        throw new Error("Method not implemented.");
    };
    ElicitBlock.prototype.typeElicitSlot = function () {
        throw new Error("Method not implemented.");
    };
    ElicitBlock.prototype.setElicitSlot = function (slot) {
        throw new Error("Method not implemented.");
    };
    ElicitBlock.prototype.slotRequired = function () {
        throw new Error("Method not implemented.");
    };
    return ElicitBlock;
}());
exports.ElicitBlock = ElicitBlock;
