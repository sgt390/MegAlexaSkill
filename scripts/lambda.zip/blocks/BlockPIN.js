"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var BlockPIN = /** @class */ (function () {
    function BlockPIN(pinConfig) {
        var _pinConfig = pinConfig;
        this.correctPIN = _pinConfig.PIN;
        this.userPIN = '';
    }
    BlockPIN.prototype.text = function () {
        var response = 'say your pin to continue';
        if (this.userPIN != '') {
            if (this.check(this.correctPIN, this.userPIN)) {
                response = 'pin is correct.';
            }
            else {
                response = 'incorrect, please repeat';
                this.setElicitSlot('');
            }
        }
        return response;
    };
    BlockPIN.prototype.check = function (PIN, userPIN) {
        return PIN === userPIN;
    };
    BlockPIN.prototype.slotRequired = function () {
        if (this.userPIN == '') {
            return true;
        }
        else {
            return false;
        }
    };
    BlockPIN.prototype.typeElicitSlot = function () {
        return "PIN";
    };
    BlockPIN.prototype.setElicitSlot = function (slot) {
        this.userPIN = slot;
    };
    return BlockPIN;
}());
exports.BlockPIN = BlockPIN;
